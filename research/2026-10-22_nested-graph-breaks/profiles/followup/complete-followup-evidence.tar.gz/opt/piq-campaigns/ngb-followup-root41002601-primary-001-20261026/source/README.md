# Bounded nested-graph follow-up diagnostics

This directory contains a standalone controller/worker CLI for closing the
small empirical gaps raised in the public follow-up questions. It writes local
diagnostic evidence only. It does not post, schedule, send, access an account,
claim a GPU, or modify the frozen benchmark and retained results.

## Files

- `nested_graphs_diagnostic.py` launches every cell in a fresh Python process,
  verifies the frozen source hashes, creates unique empty Inductor and Triton
  caches, records bounded evidence, cleans only its own temporary caches, and
  writes a terminal `COMPLETE.json` or `PARTIAL.json` handback.
- This `README.md` defines the execution and interpretation contract.

The CLI imports the original workload generator and correctness helper from a
read-only `2026-10-22_nested-graph-breaks` source directory. It refuses source
drift from these accepted SHA-256 values:

| File | SHA-256 |
| --- | --- |
| `benchmark.py` | `4c7a5a8dcef474405be19a87d22cfdeb7ea564c76f19acc67ddcd1125d247689` |
| `counter_capture.py` | `ef6c4dcb00491f1a5034ef14d55b9b505fbd9b6e744b383fd6d8c2868a938583` |
| `profile_capture.py` | `ab2bf71e11dab69f0e35f615a6810a15d883a6f26b9bb64430ff24f7d8e9f02e` |

The original directory is read only. `-B` prevents Python bytecode writes into
it. The diagnostic never imports or calls the frozen worker's `main` function.
It reuses `_build_workload`, `_correctness`, fixed constants, counter capture,
and untimed profile capture while keeping its new measurements in a distinct
output root.

## What each fresh process measures

Three disjoint process kinds prevent observer work from contaminating the
question it is meant to answer:

1. `timeline` runs one case, seed, flag arm, and compile variant. It records
   3,000–4,000 synchronized per-call intervals, cumulative active-call time,
   and continuous wall time beginning immediately before the first compiled
   call. The lazy compile and first CUDA Graph capture are therefore inside the
   horizon. Imports, input creation, and eager-reference work are outside it.
2. `memory` records current and peak allocated/reserved CUDA memory plus current
   and high-water host RSS after eager setup, the first compiled call, call 25,
   call 100, and the final horizon. Peak counters are reset only at declared
   phase boundaries. This process is not used for break-even timing.
3. `profile` warms the callable and captures five untimed CPU/CUDA Chrome-trace
   invocations for depth 8. It retains CUDA Graph launch counts, kernel counts,
   CPU marker intervals, CUDA-event intervals, CUDA API union time, kernel
   active-time union, launch-to-first-kernel delay, GPU kernel span, and idle
   time inside that span.

All paths use the original FP32, 1,048,576-element nested-frame workload,
`torch.compile`, Inductor, `fullgraph=False`, disabled persistent graph caches,
one compile thread, eager correctness tolerances, and the probed
`nested_graph_breaks=False` baseline. The original variant uses exact
`reduce-overhead` mode. Every result records the actual GPU name, compute
capability, total memory, UUID and driver version when exposed by Torch,
Torch/CUDA/cuDNN versions, Python, hostname, and platform. There is no B200
model check, so the same source can produce separately scoped evidence on
another CUDA GPU.

## Preconditions owned by the executor

Do not run this from an idle-GPU observation. The authorized hardware owner
must establish and retain all of these conditions first:

- exclusive ownership of one physical GPU and the right to execute this bounded
  diagnostic
- a full `GPU-...` UUID set as the only `CUDA_VISIBLE_DEVICES` entry
- no competing work on that device
- an authoritative, read-only source directory matching all three hashes above
- an absolute output path that does not exist, whose parent already exists
- enough time for the declared process plan, capped at 180 seconds by the CLI

The controller fails closed on the first failed or timed-out child. It never
reuses an output root. A `PARTIAL.json` preserves completed cells and the exact
failure. Temporary cache cleanup is restricted to the newly created
`ngbdiag-*` directory directly under the system temporary directory.

## Laptop-only validation

These operations use only the Python standard library. They do not import
Torch or touch CUDA:

```bash
python3 -m py_compile nested_graphs_diagnostic.py
python3 nested_graphs_diagnostic.py --help
python3 nested_graphs_diagnostic.py plan
```

The `plan` output must report `"torch_imported": false`.

## Execution sequence on an authorized GPU host

### 1. Inspect the minimum plan

The default plan is the smallest useful primary diagnostic: depth 8, both flag
arms, seeds 0 and 1 in alternating order, a 3,500-call horizon, two memory
cells, and two untimed profile cells.

```bash
python3 nested_graphs_diagnostic.py plan \
  --cases nested_break_depth8 \
  --seeds 0 1 \
  --horizon 3500
```

### 2. Run the minimum primary diagnostic

Use literal absolute paths selected by the current owner. The output root must
be new. The CLI will reject a reused path.

```bash
export CUDA_VISIBLE_DEVICES=GPU-REPLACE-WITH-OWNER-GRANTED-UUID
python3 nested_graphs_diagnostic.py run \
  --original-root /absolute/read-only/2026-10-22_nested-graph-breaks \
  --output-root /absolute/new/nested-graph-follow-up-primary \
  --expected-gpu-uuid GPU-REPLACE-WITH-OWNER-GRANTED-UUID \
  --cases nested_break_depth8 \
  --seeds 0 1 \
  --diagnostic-seed 0 \
  --horizon 3500 \
  --child-timeout-seconds 45 \
  --total-budget-seconds 170
```

### 3. Add depth 4 and the no-break control only if the budget remains valid

This plan adds the descriptive nested depth-4 case and the no-break drift
control. Inspect the plan before execution. If its observed per-child times
cannot fit inside 170 seconds, keep the primary result and schedule the added
cases as a separate new output root instead of weakening timeouts or crossing
the three-minute ceiling.

```bash
python3 nested_graphs_diagnostic.py plan \
  --cases nested_break_depth8 nested_break_depth4 no_break_depth4 \
  --seeds 0 1 \
  --horizon 3500
```

```bash
python3 nested_graphs_diagnostic.py run \
  --original-root /absolute/read-only/2026-10-22_nested-graph-breaks \
  --output-root /absolute/new/nested-graph-follow-up-depth-control \
  --expected-gpu-uuid GPU-REPLACE-WITH-OWNER-GRANTED-UUID \
  --cases nested_break_depth8 nested_break_depth4 no_break_depth4 \
  --seeds 0 1 \
  --diagnostic-seed 0 \
  --horizon 3500 \
  --child-timeout-seconds 45 \
  --total-budget-seconds 170
```

### 4. Optional no-CUDA-Graph isolation variant

Run this in a separate output root. It is an ablation, not part of the original
measurement. The retained build's `reduce-overhead` mode contains only one mode
option, `triton.cudagraphs=True`. The variant supplies the same option as
`False` without also passing the contradictory mode name.

```bash
python3 nested_graphs_diagnostic.py run \
  --original-root /absolute/read-only/2026-10-22_nested-graph-breaks \
  --output-root /absolute/new/nested-graph-follow-up-cudagraph-ablation \
  --expected-gpu-uuid GPU-REPLACE-WITH-OWNER-GRANTED-UUID \
  --cases nested_break_depth8 \
  --seeds 0 1 \
  --variants original no-cudagraph \
  --diagnostic-seed 0 \
  --horizon 3500 \
  --child-timeout-seconds 45 \
  --total-budget-seconds 170
```

The ablation is valid only when the original profiles retain positive
`cudaGraphLaunch` and kernel events, while both no-CUDA-Graph profiles retain
zero `cudaGraphLaunch` events, positive kernels, complete invocations, and
stable compiler counters. Any other outcome fails closed. Even a valid
difference-in-differences result does not by itself produce a causal percentage
split between host launch gaps and GPU execution.

## Reading the output

`summary.json` contains only paired arithmetic over passed cells. It reports:

- the first observed cumulative call where `True` is no slower than `False`
- the first such call that remains no slower through the end of the observed
  horizon
- separate crossover fields for continuous wall time and the sum of active
  synchronized calls
- phase-by-phase memory values and candidate-minus-baseline byte differences
- retained launch/kernel counts and per-invocation trace geometry

The raw arrays and actual hardware identity remain in each
`cells/<cell-id>/result.json`. The summary does not pool seeds, construct a
confidence interval, declare memory equivalence, or compute a causal
host-versus-GPU percentage.

## Minimum evidence by reader question

### Break-even over longer runs

Require both depth-8 arms for at least two alternating-order seeds, 3,000–4,000
calls per fresh process, passing final eager correctness, and an observed
`first_sustained_candidate_le_baseline_call` within the horizon. Report every
seed separately. If the field is `null`, the gap remains open beyond the tested
horizon. Depth 4 requires its own paired cells and remains descriptive unless a
new primary rule is declared before execution.

### Memory footprint

Require passing memory cells for both arms on the same case, seed, hardware,
runtime, and compile variant. Report allocated and reserved CUDA memory and host
RSS separately at every phase. “Consistent” still requires a tolerance chosen
before looking at values. Without that tolerance, report literal byte deltas
only. Driver allocations outside Torch and precise per-node CUDA Graph pool
ownership remain outside this diagnostic.

### Host gaps versus GPU scheduling

Require both passing depth-8 profile cells and their raw Chrome traces. The
trace can establish how many launches and kernels occurred and describe
time-correlated CPU/API/kernel intervals. It cannot assign a causal percentage
of the 4.53× result. A stronger causal test needs the separately validated
no-CUDA-Graph variant or another predeclared launch-overhead ablation, repeated
across paired processes, with every interval reconciled to synchronized
end-to-end timing. NCU characterizes selected kernels and must not be presented
as whole-invocation GPU time.

### Hardware portability

Run the same source and plan on each target GPU with a distinct output root.
Require actual identity readback and complete paired evidence on every target.
One new GPU result answers only that GPU/runtime combination. Cross-GPU pooling
or a universal portability claim remains unsupported.

### Real-training relevance

This script intentionally reuses the exact synthetic nested-frame workload. It
cannot close the real-training, optimizer, distributed, serving, or model
quality gaps. Those require a separately predeclared representative workload.

## Literal gaps until an authorized run completes

- No new memory values exist.
- No 3,500-call break-even horizon has been observed.
- No new host/API/kernel trace decomposition has been captured.
- No no-CUDA-Graph ablation has been validated.
- No additional GPU architecture has been tested.
- No representative model training or serving workload has been tested.

Keep all resulting replies as unscheduled drafts until the user separately
authorizes posting. A local `COMPLETE.json` is execution evidence, not a social
publication receipt.
